<?php

include 'Telegram.php';
include 'User.php';
include 'Texts.php';
include 'Steps.php';
include 'CallbackData.php';
include 'Admin.php';

require_once 'questions.php';

$bot_user_token = '1192533019:AAHB-xbDuhTbePKEPqH6Hh3mH_gBEJ7DL6U';

$bot_admin_token = '1117902598:AAGNNAmMfoZsodJd7NUuzgqUMYCwEoU1aLM';

// Instances the class

$telegramUser = new Telegram($bot_user_token);

$telegramAdmin = new Telegram($bot_admin_token);

$text = $telegramUser->Text();

$chatID = $telegramUser->ChatID();

$callback_query = $telegramUser->Callback_Query();

if ($chatID == null) {

    $chatID = 635793263;

}

// Instances the class

$user = new User($chatID);
$currStep = $user->getStep();

// bot works normally
echo "<br />";
echo 'vse norm';
echo "<br />";

echo $user->getGender();
echo "<br />";
echo $currStep;

// main logic
if ($callback_query !== null && $callback_query != '') {

    $callback_data = $telegramUser->Callback_Data();

    $chatID = $telegramUser->Callback_ChatID();

    switch ($callback_data) {
        case CallbackData::MALE:
            $user->setGender("Мужчина");
            chooseAge();
            break;
        case CallbackData::FEMALE:
            $user->setGender("Женщина");
            chooseAge();
            break;
        case CallbackData::AGE_1:
            $user->setAge(Texts::BTN_AGE_1);
            askQuestion();
            break;
        case CallbackData::AGE_2:
            $user->setAge(Texts::BTN_AGE_2);
            askQuestion();
            break;
        case CallbackData::AGE_3:
            $user->setAge(Texts::BTN_AGE_3);
            askQuestion();
            break;


    }

    // answer nothing with answerCallbackQuery, because it is required

    $content = ['callback_query_id' => $telegramUser->Callback_ID(), 'text' => '', 'show_alert' => false];

    $telegramUser->answerCallbackQuery($content);

} elseif ($text == '/start') {
    chooseGender();
} elseif ($text == Texts::BTN_ABOUT) {
    sendAbout();
} else { // steps
    switch ($currStep) {
        case Steps::GENDER:
            chooseGender();
//            switch ($text) {
//                case Texts::BTN_MALE:
//                    $user->setGender("male");
//                    chooseAge();
//                    break;
//                case Texts::BTN_FEMALE:
//                    $user->setGender("female");
//                    chooseAge();
//                    break;
//                default:
//                    chooseGender();
//                    break;
//            }
            break;
        case Steps::AGE:
            chooseAge();
//            switch ($text) {
//                case Texts::BTN_AGE_1:
//                case Texts::BTN_AGE_2:
//                case Texts::BTN_AGE_3:
//                    $user->setAge($text);
//                    askQuestion();
//                    break;
//                default:
//                    chooseAge();
//                    break;
//            }
            break;
        case Steps::QUESTION:
            waitAnswer();
            break;
    }
}

function chooseGender() {
    global $telegramUser, $user;

    $user->setStep(Steps::GENDER);

    if ($telegramUser->Text() == "/start") {
        $text = Texts::TXT_START;
    } else {
        $text = Texts::TXT_CHOOSE_GENDER;
    }

    $option = [
        // first row
        [$telegramUser->buildInlineKeyboardButton(Texts::BTN_MALE, "", CallbackData::MALE),
        $telegramUser->buildInlineKeyboardButton(Texts::BTN_FEMALE, "", CallbackData::FEMALE)],
        ];
    $keyboard = $telegramUser->buildInlineKeyBoard($option);
    $content = array('chat_id' => $telegramUser->chatID(), 'reply_markup' => $keyboard, 'text' => $text);

    $telegramUser->sendMessage($content);

}

function chooseAge() {
    global $telegramUser, $user, $callback_query;

    $user->setStep(Steps::AGE);

    $option = [
        // first row
        [$telegramUser->buildInlineKeyboardButton(Texts::BTN_AGE_1, "", CallbackData::AGE_1),
            $telegramUser->buildInlineKeyboardButton(Texts::BTN_AGE_2, "", CallbackData::AGE_2),
            $telegramUser->buildInlineKeyboardButton(Texts::BTN_AGE_3, "", CallbackData::AGE_3),]
    ];
    $keyboard = $telegramUser->buildInlineKeyBoard($option);
    $content = array('chat_id' => $telegramUser->chatID(), 'message_id' => $callback_query['message']['message_id'], 'text' => Texts::TXT_CHOOSE_AGE, 'reply_markup' => $keyboard);

    $telegramUser->editMessageText($content);
}

function askQuestion() {
    global $telegramUser, $user, $callback_query;

    $user->setStep(Steps::QUESTION);

    $option = [[$telegramUser->buildKeyboardButton(Texts::BTN_ABOUT)]];
    $keyboard = $telegramUser->buildKeyBoard($option, $onetime=true, $resize=true);
    $content = array('chat_id' => $telegramUser->chatID(), 'message_id' => $callback_query['message']['message_id'], 'text' => Texts::TXT_ASK_QUESTION);

    $telegramUser->editMessageText($content);
}

function sendAbout() {
    global $telegramUser, $user;

    $content = array('chat_id' => $telegramUser->chatID(), 'text' => Texts::TXT_ABOUT);
    $telegramUser->sendMessage($content);
}

function waitAnswer() {
    global $telegramUser, $user;

    $user->setStep(Steps::QUESTION);

    saveQuestion($telegramUser->ChatID(), $telegramUser->Text());

    notifyAdmin();

    $content = array('chat_id' => $telegramUser->chatID(), 'text' => Texts::TXT_WAIT_ANSWER);
    $telegramUser->sendMessage($content);
}

function notifyAdmin() {
    global $telegramAdmin;

    foreach (Admin::admins as $chatID) {
        $content = array('chat_id' => $chatID, 'text' => "Поступил новый вопрос");
        $telegramAdmin->sendMessage($content);
    }
}


