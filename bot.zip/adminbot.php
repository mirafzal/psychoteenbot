<?php

include 'Telegram.php';
include 'Admin.php';
include 'Texts.php';

require_once 'questions.php';

$bot_admin_token = '1117902598:AAGNNAmMfoZsodJd7NUuzgqUMYCwEoU1aLM';

$bot_user_token = '1192533019:AAHB-xbDuhTbePKEPqH6Hh3mH_gBEJ7DL6U';

// Instances the class

$telegramAdmin = new Telegram($bot_admin_token);

$telegramUser = new Telegram($bot_user_token);

$text = $telegramAdmin->Text();

$chatID = $telegramAdmin->ChatID();

$callback_query = $telegramAdmin->Callback_Query();

$messageID = $telegramAdmin->getData()['message']['message_id'];

saveLastMessageId($chatID, $messageID);

$messageID1 = getData(13)[AdminTableKeys::ANSWER_MESSAGE_ID];

if ($chatID == null) {

    $chatID = 635793263;

}

$txt = json_encode($telegramAdmin->getData(), JSON_PRETTY_PRINT);

$content = array('chat_id' => $telegramAdmin->ChatID(), 'text' => $txt);
$telegramAdmin->sendMessage($content);

$content = array('chat_id' => $telegramAdmin->ChatID(), 'text' => $messageID1);
$telegramAdmin->sendMessage($content);

$content = ['chat_id' => $telegramAdmin->ChatID(), 'message_id' => $messageID1];
$telegramAdmin->deleteMessage($content);

$admin = new Admin($chatID);

if (in_array($chatID, Admin::admins)) {
    if ($callback_query !== null && $callback_query != '') {

        $callback_data = $telegramAdmin->Callback_Data();
        $chatID = $telegramAdmin->Callback_ChatID();

        switch ($admin->getStep()) {
            case Steps::ADMIN_QUESTIONS:
                showChosenQuestion($callback_data);
                break;
            case Steps::ADMIN_ANSWERING:
                switch ($callback_data) {
                    case CallbackData::CANCEL:
                        // TODO
                        break;
                    case CallbackData::REJECT:
                        // TODO
                        break;
                }
                break;
        }

        // answer nothing with answerCallbackQuery, because it is required
        $content = ['callback_query_id' => $telegramAdmin->Callback_ID(), 'text' => '', 'show_alert' => false];
        $telegramAdmin->answerCallbackQuery($content);

    } elseif ($text == "/start") {
        sendWelcomeMessage();
    } elseif ($text == Texts::BTN_ANSWER) {
        showQuestionsList();
    }
}

function sendWelcomeMessage()
{
    global $telegramAdmin;

    $option = [
        [$telegramAdmin->buildKeyboardButton(Texts::BTN_ANSWER)],
    ];
    $keyb = $telegramAdmin->buildKeyBoard($option, $onetime = false, $resize = true);
    $content = array('chat_id' => $telegramAdmin->ChatID(), 'reply_markup' => $keyb, 'text' => Texts::TXT_WELCOME);
    $telegramAdmin->sendMessage($content);
}

function showQuestionsList()
{
    global $telegramAdmin, $admin;
    $admin->setStep(Steps::ADMIN_QUESTIONS);
    if (empty(getAllQuestionsIds())) {
        $content = array('chat_id' => $telegramAdmin->ChatID(), 'text' => Texts::TXT_NO_QUESTION);
        $telegramAdmin->sendMessage($content);
    } else {
        $option = [];
        foreach (getAllQuestionsIds() as $id) {
            $option[] = [$telegramAdmin->buildInlineKeyBoardButton($id . "", $url = "", $callback_data = $id . "")];
        }
        $keyb = $telegramAdmin->buildInlineKeyBoard($option);
        $content = array('chat_id' => $telegramAdmin->ChatID(), 'reply_markup' => $keyb, 'text' => Texts::TXT_CHOOSE_QUESTION);
        $telegramAdmin->sendMessage($content);
    }
}

function showChosenQuestion($id)
{
    global $telegramAdmin, $admin;
    
    $admin->setStep(Steps::ADMIN_ANSWERING);

    $admin->setAnsweringQuestionId($id);

    $question = getData($id)[AdminTableKeys::QUESTION];
    $option = [
        [$telegramAdmin->buildKeyboardButton(Texts::BTN_NOT_CORRECT_QUESTION, "", CallbackData::REJECT),
            $telegramAdmin->buildInlineKeyboardButton(Texts::BTN_CANCEL, "", CallbackData::CANCEL)],
    ];
    $keyb = $telegramAdmin->buildKeyBoard($option, $onetime = false, $resize = true);
    $content = array('chat_id' => $telegramAdmin->ChatID(), 'reply_markup' => $keyb, 'text' => Texts::TXT_WRITE_ANSWER . $question);
    $telegramAdmin->sendMessage($content);
}

function answerToUser() {
    global $telegramAdmin, $telegramUser, $admin;

    $admin->setStep(Steps::ADMIN_QUESTIONS);

    $questionId = $admin->getAnsweringQuestionId();

    saveAnswer($questionId, $telegramAdmin->Text());

    $content = array('chat_id' => getData($questionId)[AdminTableKeys::CHAT_ID], 'text' => $telegramAdmin->Text());
    $telegramUser->sendMessage($content);

}



