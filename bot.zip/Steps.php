<?php

class Steps
{
    const
        GENDER = 0,
        AGE = 1,
        QUESTION = 2;

    const
        ADMIN_QUESTIONS = 3,
        ADMIN_ANSWERING = 4;
}